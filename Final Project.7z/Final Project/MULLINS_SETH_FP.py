# Program name:MULLINS_SETH_FP
# Author: Seth Mullins
# Date: 4/25/22
# Summary: User will choose between a video game package (2,3,5) and a genre
# and will be given a random selection of games up to desried amount
# Variables:
#   packageType: the package type that user wants (int)
#   genre: genre the user wants (str)
#   action: list of games that fit the action genre (str)
#   chill: list of games that fit the chill genre (str)

def main():

    # choose package and genre
    packageType = int(input("What package type would you like? (2, 3, 5)?: "))
    if packageType == 2:
        genre = str(input("You picked the 2 game package. What genre would you like? [Action or Chill]: "))
        if genre == "Action":
              with open("ActionGame.txt") as file:
                   print(file.readline())
                   print(file.readline())
        elif genre == "Chill":
              with open("ChillGame.txt") as file:
                   print(file.readline())
                   print(file.readline())
        else:
            print("ERROR... Please choose [Action / Chill].")
           
    elif packageType == 3:
        genre = str(input("You picked the 3 game package. What genre would you like? [Action or Chill]: "))
        if genre == "Action":
              with open("ActionGame.txt") as file:
                   print(file.readline())
                   print(file.readline())
                   print(file.readline()) 
        elif genre == "Chill":
              with open("ChillGame.txt") as file:
                   print(file.readline())
                   print(file.readline())
                   print(file.readline())
        else:
            print("ERROR... Please choose [Action / Chill].")
                   
    elif packageType == 5:
        genre = str(input("You picked the 5 game package. What genre would you like? [Action or Chill]: "))
        if genre == "Action":
              with open("ActionGame.txt") as file:
                   print(file.readline())
                   print(file.readline())
                   print(file.readline())
                   print(file.readline())
                   print(file.readline())
        elif genre == "Chill":
              with open("ChillGame.txt") as file:
                   print(file.readline())
                   print(file.readline())
                   print(file.readline())
                   print(file.readline())
                   print(file.readline())
        else:
            print("ERROR... Please choose [Action / Chill].")

                   
    else:
        print("ERROR... Package type does not exist.")
        
        

main()

